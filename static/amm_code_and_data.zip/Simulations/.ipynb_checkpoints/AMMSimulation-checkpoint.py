# Name: UniswapSimulation.py
# Author: Scott Condie (ssc@byu.edu)
# Description: Numerically calculates an equilibrium in an AMM exchange

from scipy import stats
from scipy.integrate import quad
from scipy.optimize import fsolve
import matplotlib.pyplot as plt
import numpy as np
from functools import partial
# Distribution for epsilonx, and v

Feps = stats.norm
eps_param = 5
Fv = stats.norm
Fv_param = 100
K = 10
x = 100
y = 100

def deltaxfunc(x, K, deltax, eps):
    return K/(x - deltax - eps)**2

def intfunc(deltax):
    def outfunc(eps):
        return deltaxfunc(x,K,deltax,eps)*Feps.pdf(eps, 5, 5)
    res, err = quad(outfunc, -np.infty, np.infty)
    return res

dxs = np.linspace()



def solve_func(v,deltax):
    return v - intfunc(deltax)

vvals = np.linspace(1, 2, 10)

dxvals = []
for vv in vvals:
    g = partial(solve_func,vv)
    dx = fsolve(g, 15)
    dxvals.append(dx.item())

plt.plot(vvals, dxvals)
plt.show()


"""
def solveDeltax(feps):
    v_vals = np.linspace(0,100,200)
    epsdist = feps.pdf(eps_param)
    g = intfunc() = partial(deltaxfunc, K=K)
        return 
"""
