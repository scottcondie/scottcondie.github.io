# Name: UniswapSimulation.py
# Author: Scott Condie (ssc@byu.edu)
# Description: Numerically calculates an equilibrium in an AMM exchange

from scipy import stats
from scipy.integrate import quad
from scipy.optimize import fsolve
import matplotlib.pyplot as plt
import numpy as np
from functools import partial
# Distribution for epsilonx, and v
eps_min = -1
eps_max = 1
Feps = stats.uniform(eps_min, eps_max)
Fv = stats.norm
Fv_param = 100
K = 100
x = 10
y = 10

def deltaxfunc(x, K, deltax, eps):
    return K/(x - deltax - eps)**2

def intfunc(deltax):
    def outfunc(eps):
        return deltaxfunc(x,K,deltax,eps)*Feps.pdf(eps)
    res, err = quad(outfunc, eps_min,eps_max)
    return res

def cost_func(deltax, x, y, K, eps_x, eps_y):
    return K/(x - deltax - eps_x) - (y + eps_y)

def expected_profit(v, deltax, x, y, K):
    res, err = quad()
    return v*deltax - K/()



dxs = np.linspace(-2,2,20)

print(dxs)

def solve_func(v,deltax):
    return v - intfunc(deltax)

#dxvals = [ solve_func(1.03, xx) for xx in dxs]


vvals = np.linspace(0.7, 1.30, 10)

dxvals = []
for vv in vvals:
    g = partial(solve_func,vv)
    dx = fsolve(g,1.0 )
    dxvals.append(dx.item())

plt.plot(vvals, dxvals)
plt.show()

"""
def solveDeltax(feps):
    v_vals = np.linspace(0,100,200)
    epsdist = feps.pdf(eps_param)
    g = intfunc() = partial(deltaxfunc, K=K)
        return 
"""
